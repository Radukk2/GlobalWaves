package app.pages;

import app.user.User;

interface UserPages {
    String displayPage(User user);
}
