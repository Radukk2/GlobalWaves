package app.pages;

import app.user.SpecialUsers;

interface SpecialPages {

    String showPage(SpecialUsers specialUsers);
}
